const Lead = require("../models/LeadModel");
const User = require("../models/UserModel");
const Vendor = require("../models/VendorModel");
const argon2 = require("argon2");

const createLead = async (req, res) => {
    const { name, email, password, confPassword, mobile, address, product_category, product_selection, lead_status, vendorId,  createdByName } = req.body;

    if (password !== confPassword) {
        return res.status(400).json({ msg: "Password and Confirm Password do not match" });
    }

    const hashPassword = await argon2.hash(password);

    try {
        // Step 1: Create User with role 'lead'
        const user = await User.create({
            name: name,
            email: email,
            password: hashPassword,
            role: 'lead',
            createdBy: vendorId,
            copyofpassword: password // This field should be used cautiously
        });

        // Step 2: Create Lead with the User's UUID
        const lead = await Lead.create({
            uuid: user.uuid,
            name: name,
            email: email,
            mobile: mobile,
            address: address,
            product_category: product_category,
            product_selection: product_selection,
            lead_status: lead_status,
            createdBy: vendorId,
            createdByName: createdByName
        });

        res.status(201).json({ msg: "Lead created successfully", lead });
    } catch (error) {
        res.status(400).json({ msg: error.message });
    }
};

const getLeads = async (req, res) => {
    try {
        const response = await Lead.findAll({
            attributes: ['uuid', 'name', 'email', 'mobile', 'address', 'product_category', 'product_selection', 'lead_status', 'createdByName', 'createdAt', 'createdBy'],
            include: {
                model: User,
                attributes: ['uuid', 'name', 'email', 'role']
            }
        });
        res.status(200).json(response);
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
};

const getLeadById = async (req, res) => {
    try {
        const lead = await Lead.findOne({
            where: {
                uuid: req.params.id
            },
            include: {
                model: User,
                attributes: ['uuid', 'name', 'email', 'role']
            }
        });

        if (!lead) {
            return res.status(404).json({ msg: "Lead not found" });
        }

        res.status(200).json(lead);
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
};

const getLeadByVendor = async (req, res) => {
    try {
        const lead = await Lead.findAll({
            where: {
                createdBy: req.params.id
            },
            include: {
                model: User,
                attributes: ['uuid', 'name', 'email', 'role']
            }
        });

        if (!lead) {
            return res.status(404).json({ msg: "Lead not found" });
        }

        res.status(200).json(lead);
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
};

const updateLead = async (req, res) => {
    try {
        const lead = await Lead.findOne({
            where: {
                uuid: req.params.id
            }
        });

        if (!lead) {
            return res.status(404).json({ msg: "Lead not found" });
        }

        const { name, email, mobile, address, product_category, product_selection, lead_status } = req.body;
        lead.name = name || lead.name;
        lead.email = email || lead.email;
        lead.mobile = mobile || lead.mobile;
        lead.address = address || lead.address;
        lead.product_category = product_category || lead.product_category;
        lead.product_selection = product_selection || lead.product_selection;
        lead.lead_status = lead_status || lead.lead_status;

        await lead.save();
        res.status(200).json({ msg: "Lead updated successfully" });
    } catch (error) {
        res.status(400).json({ msg: error.message });
    }
};

const changeStatus = async (req, res) => {
    try {
        
        const { uuid, lead_status } = req.body;
        const lead = await Lead.findOne({
            where: {
                uuid
            }
        });

        if (!lead) {
            return res.status(404).json({ msg: "Lead not found" });
        }

        // Update lead status to "Trade Done"
        lead.lead_status = lead_status;

        await lead.save();
        res.status(200).json({ msg: "Lead converted successfully" });
    } catch (error) {
        res.status(400).json({ msg: error.message });
    }
};


const deleteLead = async (req, res) => {
    try {
        const lead = await Lead.findOne({
            where: {
                uuid: req.params.id
            }
        });

        if (!lead) {
            return res.status(404).json({ msg: "Lead not found" });
        }

        await Lead.destroy({
            where: {
                uuid: req.params.id
            }
        });

        res.status(200).json({ msg: "Lead deleted successfully" });
    } catch (error) {
        res.status(400).json({ msg: error.message });
    }
};

module.exports = {
    createLead,
    getLeads,
    getLeadById,
    getLeadByVendor,
    updateLead,
    deleteLead,
    changeStatus
};