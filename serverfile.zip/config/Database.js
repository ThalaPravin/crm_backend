
const Sequelize = require("sequelize");
const db = new Sequelize('crm', 'root', '', {
    host: "localhost",
    dialect: "mysql"
});
// const db = new Sequelize('fyjrbbgt_crm', 'fyjrbbgt_siddharth', 'Siddharth@123', {
//     host: "localhost",
//     dialect: "mysql"
// });
 
module.exports = db;
