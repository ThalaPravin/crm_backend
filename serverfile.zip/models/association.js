
function associateModels() {

}

module.exports = associateModels;
